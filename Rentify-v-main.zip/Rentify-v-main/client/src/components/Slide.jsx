import "../styles/Slide.scss"

const Slide = () => {
  return (
    <div className="slide">
      <h1>
        Welcome Home! Anywhere you Go <br /> Enjoy the moment. Make your
        memories
      </h1>
    </div>
  );
};

export default Slide;
